import { Card } from "@/components/ui/card"

export function About() {
  return (
    <section id="about" className="container mx-auto px-4 py-20 md:py-28">
      <div className="max-w-4xl">
        <h2 className="mb-4 text-sm font-mono text-primary">About</h2>
        <h3 className="mb-12 text-3xl md:text-4xl font-bold tracking-tight">Building Secure Digital Solutions</h3>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="p-6 bg-card border-border">
            <div className="mb-4">
              <div className="text-2xl font-bold text-primary">B.E - CSE</div>
              <div className="text-sm text-muted-foreground">Cyber Security</div>
            </div>
            <div className="space-y-2 text-sm">
              <p className="text-foreground">Karpagam University, Coimbatore</p>
              <p className="text-muted-foreground">2023 - 2027</p>
              <p className="text-muted-foreground">CGPA: 6.77</p>
            </div>
          </Card>

          <Card className="p-6 bg-card border-border">
            <div className="mb-4">
              <div className="text-2xl font-bold text-primary">Location</div>
              <div className="text-sm text-muted-foreground">Based in Salem</div>
            </div>
            <div className="space-y-2 text-sm">
              <p className="text-foreground">jayakrishnan91234@gmail.com</p>
              <p className="text-muted-foreground">+91 9345532867</p>
            </div>
          </Card>
        </div>
      </div>
    </section>
  )
}
