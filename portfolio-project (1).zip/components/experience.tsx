import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const internships = [
  {
    title: "Artificial Intelligence Workshop",
    organization: "IIT Madras Research Park",
    location: "Chennai",
    description: "Participated in hands-on AI workshop exploring machine learning concepts and applications",
  },
  {
    title: "UI/UX Design",
    organization: "Gateway Software Solution",
    location: "Coimbatore",
    description: "Learned user-centric design principles and prototyping tools for web applications",
  },
  {
    title: "Full Stack Development",
    organization: "Pantech E-Learning",
    location: "Chennai",
    description: "Comprehensive training in modern web development technologies and best practices",
  },
  {
    title: "Cybersecurity Foundations",
    organization: "BCBUZZ Technologies Pvt Ltd",
    location: "Coimbatore",
    description: "Intensive training in cybersecurity fundamentals and threat mitigation strategies",
  },
]

const certifications = [
  { name: "Introduction to Internet of Things", issuer: "Swayam" },
  { name: "Google Cloud", issuer: "Google" },
  { name: "Cyber Thread Management", issuer: "Cisco" },
  { name: "Ethical Hacking", issuer: "Cisco" },
  { name: "Networking Defence", issuer: "Cisco" },
  { name: "Angular Web Developer", issuer: "Infosys" },
  { name: "Agile Scrum", issuer: "Infosys" },
  { name: "Prompt Engineering", issuer: "Infosys" },
]

export function Experience() {
  return (
    <section id="experience" className="container mx-auto px-4 py-20 md:py-28">
      <div className="max-w-4xl">
        <h2 className="mb-4 text-sm font-mono text-primary">Experience</h2>
        <h3 className="mb-12 text-3xl md:text-4xl font-bold tracking-tight">Internships & Certifications</h3>

        <div className="mb-16">
          <h4 className="mb-6 text-xl font-semibold">Internships</h4>
          <div className="space-y-6">
            {internships.map((internship) => (
              <Card key={internship.title} className="p-6 bg-card border-border">
                <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-3">
                  <div>
                    <h5 className="text-lg font-semibold mb-1">{internship.title}</h5>
                    <p className="text-sm text-muted-foreground">
                      {internship.organization} • {internship.location}
                    </p>
                  </div>
                </div>
                <p className="text-sm text-foreground/80 leading-relaxed">{internship.description}</p>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <h4 className="mb-6 text-xl font-semibold">Certifications</h4>
          <Card className="p-6 bg-card border-border">
            <div className="flex flex-wrap gap-3">
              {certifications.map((cert) => (
                <Badge key={cert.name} variant="outline" className="text-sm py-1.5 px-3">
                  {cert.name} • {cert.issuer}
                </Badge>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </section>
  )
}
