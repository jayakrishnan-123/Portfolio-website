import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const projects = [
  {
    title: "Portfolio Website",
    period: "Oct 2025 - Dec 2025",
    description: "Modern, responsive portfolio website showcasing technical skills and projects",
    techStack: ["HTML5", "CSS3", "JavaScript", "ReactJS", "TailwindCSS"],
    status: "Completed",
  },
  {
    title: "E-Commerce Platform",
    period: "Sep 2025 - Present",
    description:
      "Full-stack e-commerce application with user authentication, product management, and payment integration",
    techStack: ["ReactJS", "NodeJS", "ExpressJS", "Python", "MySQL", "MongoDB"],
    status: "In Progress",
  },
]

export function Projects() {
  return (
    <section id="projects" className="container mx-auto px-4 py-20 md:py-28 bg-muted/30">
      <div className="max-w-4xl">
        <h2 className="mb-4 text-sm font-mono text-primary">Projects</h2>
        <h3 className="mb-12 text-3xl md:text-4xl font-bold tracking-tight">Recent Work</h3>

        <div className="space-y-6">
          {projects.map((project) => (
            <Card key={project.title} className="p-6 bg-card border-border hover:border-primary/50 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="text-xl font-semibold mb-1">{project.title}</h4>
                  <p className="text-sm text-muted-foreground">{project.period}</p>
                </div>
                <Badge variant={project.status === "Completed" ? "default" : "secondary"}>{project.status}</Badge>
              </div>

              <p className="mb-4 text-foreground/80 leading-relaxed">{project.description}</p>

              <div className="flex flex-wrap gap-2">
                {project.techStack.map((tech) => (
                  <Badge key={tech} variant="outline" className="text-xs">
                    {tech}
                  </Badge>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
