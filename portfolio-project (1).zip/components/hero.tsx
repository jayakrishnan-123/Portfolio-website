import { Button } from "@/components/ui/button"
import { ArrowRight, Github, Linkedin, Mail } from "lucide-react"
import Link from "next/link"

export function Hero() {
  return (
    <section className="container mx-auto px-4 pt-32 pb-20 md:pt-40 md:pb-28">
      <div className="max-w-3xl">
        <div className="mb-6 text-sm font-mono text-primary">Full Stack Developer & Cybersecurity Student</div>

        <h1 className="mb-6 text-5xl md:text-7xl font-bold tracking-tight text-balance">Jayakrishnan P</h1>

        <p className="mb-8 text-lg md:text-xl text-muted-foreground leading-relaxed text-pretty">
          A curious and detail-oriented Cyber Security student with a passion for understanding how systems work and how
          to secure them. Skilled in Ethical hacking, penetration testing, and modern web development.
        </p>

        <div className="flex flex-wrap gap-4 mb-12">
          <Button asChild size="lg">
            <Link href="#projects">
              View Projects <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link href="#contact">Get in Touch</Link>
          </Button>
        </div>

        <div className="flex items-center gap-4">
          <Link
            href="https://github.com/jayakrishnan-123"
            target="_blank"
            className="text-muted-foreground hover:text-primary transition-colors"
          >
            <Github className="h-5 w-5" />
            <span className="sr-only">GitHub</span>
          </Link>
          <Link
            href="https://www.linkedin.com/in/jayakrishnan-p-538b08292"
            target="_blank"
            className="text-muted-foreground hover:text-primary transition-colors"
          >
            <Linkedin className="h-5 w-5" />
            <span className="sr-only">LinkedIn</span>
          </Link>
          <Link
            href="mailto:jayakrishnan91234@gmail.com"
            className="text-muted-foreground hover:text-primary transition-colors"
          >
            <Mail className="h-5 w-5" />
            <span className="sr-only">Email</span>
          </Link>
        </div>
      </div>
    </section>
  )
}
