import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"

const skillCategories = [
  {
    title: "Frontend Development",
    skills: ["HTML5", "CSS3", "JavaScript", "ReactJS", "TailwindCSS"],
  },
  {
    title: "Backend Development",
    skills: ["NodeJS", "ExpressJS", "PHP", "Python"],
  },
  {
    title: "Database",
    skills: ["MySQL", "MongoDB"],
  },
  {
    title: "Programming Languages",
    skills: ["C++", "Python", "JavaScript"],
  },
  {
    title: "Languages",
    skills: ["English", "Tamil", "Malayalam"],
  },
  {
    title: "Cybersecurity",
    skills: ["Ethical Hacking", "Penetration Testing", "Network Defense"],
  },
]

export function Skills() {
  return (
    <section id="skills" className="container mx-auto px-4 py-20 md:py-28 bg-muted/30">
      <div className="max-w-4xl">
        <h2 className="mb-4 text-sm font-mono text-primary">Skills</h2>
        <h3 className="mb-12 text-3xl md:text-4xl font-bold tracking-tight">Technical Expertise</h3>

        <div className="grid md:grid-cols-2 gap-6">
          {skillCategories.map((category) => (
            <Card key={category.title} className="p-6 bg-card border-border">
              <h4 className="mb-4 text-lg font-semibold">{category.title}</h4>
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill) => (
                  <Badge key={skill} variant="secondary" className="text-sm">
                    {skill}
                  </Badge>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
