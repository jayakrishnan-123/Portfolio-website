import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Mail, Phone, MapPin, Github, Linkedin } from "lucide-react"
import Link from "next/link"

export function Contact() {
  return (
    <section id="contact" className="container mx-auto px-4 py-20 md:py-28">
      <div className="max-w-4xl">
        <h2 className="mb-4 text-sm font-mono text-primary">Contact</h2>
        <h3 className="mb-12 text-3xl md:text-4xl font-bold tracking-tight">Let&apos;s Connect</h3>

        <div className="grid md:grid-cols-2 gap-6 mb-12">
          <Card className="p-6 bg-card border-border">
            <div className="flex items-start gap-4">
              <div className="mt-1 p-2 bg-primary/10 rounded-lg">
                <Mail className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h4 className="font-semibold mb-1">Email</h4>
                <a
                  href="mailto:jayakrishnan91234@gmail.com"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  jayakrishnan91234@gmail.com
                </a>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-card border-border">
            <div className="flex items-start gap-4">
              <div className="mt-1 p-2 bg-primary/10 rounded-lg">
                <Phone className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h4 className="font-semibold mb-1">Phone</h4>
                <a
                  href="tel:+919345532867"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  +91 9345532867
                </a>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-card border-border">
            <div className="flex items-start gap-4">
              <div className="mt-1 p-2 bg-primary/10 rounded-lg">
                <MapPin className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h4 className="font-semibold mb-1">Location</h4>
                <p className="text-sm text-muted-foreground">Salem, India</p>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-card border-border">
            <div className="flex items-start gap-4">
              <div className="mt-1 p-2 bg-primary/10 rounded-lg">
                <Github className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h4 className="font-semibold mb-1">GitHub</h4>
                <a
                  href="https://github.com/jayakrishnan-123"
                  target="_blank"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                  rel="noreferrer"
                >
                  github.com/jayakrishnan-123
                </a>
              </div>
            </div>
          </Card>
        </div>

        <div className="text-center">
          <p className="mb-6 text-muted-foreground">
            Open to opportunities in Full Stack Development and Cybersecurity
          </p>
          <Button asChild size="lg">
            <Link href="https://www.linkedin.com/in/jayakrishnan-p-538b08292" target="_blank">
              <Linkedin className="mr-2 h-4 w-4" />
              Connect on LinkedIn
            </Link>
          </Button>
        </div>
      </div>

      <footer className="mt-20 pt-8 border-t border-border text-center text-sm text-muted-foreground">
        <p>© {new Date().getFullYear()} Jayakrishnan P. All rights reserved.</p>
      </footer>
    </section>
  )
}
